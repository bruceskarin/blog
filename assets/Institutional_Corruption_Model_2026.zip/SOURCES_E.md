# Sources — Group E (Federal campaign-finance context series)

**Access date**: October 10, 2026
**Coverage**: election cycles 2000–2024 (E1: 2010–2024 only, post-Citizens United)
**Units**: nominal dollars. Cycle year = even year (e.g., 2024 = 2023–2024 cycle).

These are CONTEXT series for narrative/video use — broader than the House-only
calibration variables in Groups A–D. They are not fed into the model.

---

## E1 — Total Outside Spending per cycle (`E1_outside_spending.csv`)

- **Definition**: Independent expenditures + electioneering communications +
  communication costs by non-party outside groups (super PACs, 501(c)
  nonprofits/dark-money groups, unions, corporations). Excludes candidates and
  party committees. This is OpenSecrets' "Outside Spending by Cycle, Excluding
  Party Committees" concept.
- **Source**: OpenSecrets (Center for Responsive Politics) outside-spending
  reporting and news analyses, 2012–2024.
  - Landing page: https://www.opensecrets.org/outside-spending (accessed 2026-10-10;
    per-cycle chart totals are JS-rendered; figures below are OpenSecrets'
    published cycle totals as reported in their news analyses)
  - 2016 "$1.7 billion record": https://www.opensecrets.org/news/2020/08/outside-groups-spend-as-2020-election
  - 2018 "nearly $1.1 billion": https://www.opensecrets.org/news/2022/11/outside-spending-on-2022-federal-midterm-elections-tops-2-billion/ (via 2018 coverage cited therein)
  - 2022 "more than $2.1 billion": https://www.opensecrets.org/news/2022/11/outside-spending-on-2022-federal-midterm-elections-tops-2-billion/
  - 2024 "record $4.5 billion": https://www.Opensecrets.org/news/2024/11/outside-spending-on-2024-elections-shatters-records-fueled-by-billion-dollar-dark-money-infusion
  - 2010–2014 cross-checks: Public Citizen analysis of CRP data
    (2010: $294,693,518; 2012: $1,056,024,501);
    Sabato's Crystal Ball citing CRP (2014: "over $565 million"):
    https://centerforpolitics.org/crystalball/why-outside-spending-is-overrated-lessons-from-the-2014-senate-elections/
- **Methodology note**: Values are OpenSecrets' published rounded cycle totals.
  They are NOT fabricated, but they are rounded as published (to ~$10M).
- **Definition break**: Series starts 2010 because *Citizens United v. FEC*
  (Jan 2010) + *SpeechNow.org v. FEC* (Mar 2010) created super PACs; pre-2010
  outside spending (527 groups etc.) is a different regime and is excluded.
- **Flags / uncertainty**:
  - 2024 ($4.5B): published around Election Day 2024; late filings may revise it
    upward (Oct 2024 projection was "exceed $5 billion").
  - 2020 ($2.91B): OpenSecrets-derived figure; one secondary legal text cites
    $2.7B for non-party groups — definitional edge cases exist.
  - Dark-money issue ads that avoid "magic words" are NOT required to be
    reported to the FEC, so all figures understate true outside spending.

## E2 — House candidates raised/spent (`E2_house_raised_spent.csv`)

- **Columns**: year, raised (TTL_RECEIPTS), spent (TTL_DISB), summed over ALL
  House candidates per cycle (winners and losers).
- **Source**: FEC bulk data, `weball{yy}.zip` (Candidate Summary) joined to
  `cn{yy}.zip` (Candidate Master) on CAND_ID, filtering
  `CAND_OFFICE='H'` and `CAND_ELECTION_YR={cycle}`.
  - https://www.fec.gov/files/bulk-downloads/20{yy}/weball{yy}.zip
  - https://www.fec.gov/files/bulk-downloads/20{yy}/cn{yy}.zip
- **Methodology**: Column positions verified empirically — TTL_DISB (col 7)
  sums match the published A1 series exactly for every cycle 2000–2024;
  TTL_RECEIPTS is col 5. Layout stable across all cycles. Local files already
  cached in `data/work/fec/` (no re-download needed).
- **Validation**: spent column reproduces A1_total_expenditures.csv to the
  dollar for all 13 cycles.

## E3 — Senate candidates raised/spent (`E3_senate_raised_spent.csv`)

- **Same method as E2** with `CAND_OFFICE='S'`.
- **Definition note**: Only ~1/3 of Senate seats are contested each cycle, so
  cycle-to-cycle swings partly reflect which seats are up (e.g., 2020's $2.06B
  raised reflects an unusually expensive Senate map). Recorded as-is per spec.

## E4 — Presidential candidates raised/spent (`E4_presidential_raised_spent.csv`)

- **Same method as E2** with `CAND_OFFICE='P'`; presidential cycles only
  (2000, 2004, …, 2024).
- **Definition note**: Includes ALL presidential candidates filing with the FEC
  (100+ minor candidates per cycle), not just major-party nominees.
  TTL_RECEIPTS includes public matching funds / grants where applicable.
  Self-funded billionaire candidates (e.g., Bloomberg 2020, ~$1B) are included
  — this is a feature, not a bug, for the "money chase" narrative.

## E5 — Total cost of federal elections (`E5_total_federal_election_cost.csv`)

- **Definition**: OpenSecrets' "Cost of Election": all money spent on federal
  elections per cycle — presidential + Senate + House candidates, political
  parties, and independent interest groups.
- **Source**: OpenSecrets "Cost of Election" table, nominal-dollar column
  (infl=N): https://www.opensecrets.org/elections-overview/cost-of-election?cycle=2020&display=T&infl=N
  (accessed 2026-10-10). Exact nominal figures as published.
- **Internal consistency check** (2024): House spent $2.14B (E2) + Senate spent
  $1.55B (E3) + Presidential spent $2.69B (E4) = $6.38B candidate spending;
  + outside $4.5B (E1) = $10.9B; remainder ~$3.9B is party committees —
  sums plausibly to the $14.8B total.
- **Flag**: 2024 figure ($14.80B) is below OpenSecrets' Oct-2024 projection of
  $15.9B; the table appears updated with actuals but late filings may revise it.

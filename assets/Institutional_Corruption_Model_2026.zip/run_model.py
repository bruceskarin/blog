"""Run the institutional corruption Vensim model via PySD with fast lookups.

PySD's HardcodedLookups uses xarray.interp per call (~0.5s/call), which makes
a 12,800-step simulation infeasible. This patches it to np.interp for the
1D scalar case (all 15 lookups in this model use 'interpolate' mode, and
Vensim clamps out-of-range lookups to endpoints, matching np.interp default).
"""
import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pysd
from pysd.py_backend import lookups

_orig_call = lookups.HardcodedLookups._call

def _fast_call(self, data, x, final_subs=None):
    if self.is_float and not hasattr(x, 'dims'):
        xp = data['lookup_dim'].values
        fp = np.asarray(data.values, dtype=float)
        return float(np.interp(float(x), xp, fp))
    return _orig_call(self, data, x, final_subs)

lookups.HardcodedLookups._call = _fast_call


def load(path='/home/hatch/workspace/icorrupt-refresh/model/model_2026_updated.mdl'):
    return pysd.read_vensim(path)


if __name__ == '__main__':
    import time, sys
    t0 = time.time()
    m = load()
    print(f"load: {time.time()-t0:.1f}s", flush=True)
    t0 = time.time()
    cols = sys.argv[1].split(',') if len(sys.argv) > 1 else None
    r = m.run(return_columns=cols)
    print(f"full run: {time.time()-t0:.1f}s shape={r.shape}", flush=True)
    out = '/home/hatch/workspace/icorrupt-refresh/model/baseline_run.csv' if cols is None else '/home/hatch/workspace/icorrupt-refresh/model/baseline_run_subset.csv'
    r.to_csv(out)
    print("saved", out, flush=True)

"""Policy scenarios with the RECALIBRATED 2026 model.

Scenarios (all start 2027):
- baseline: no policy changes
- finance: voucher $35 + 9:1 match + cost control (combined finance reforms)
- leverage: 20% reduction in Transparency Leverage Effect
             (sunshine laws multiplier after repeal: 2 -> 1.6)
- everything: finance + leverage
"""
import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pysd
from pysd.py_backend import lookups
import time, os

_orig_call = lookups.HardcodedLookups._call
def _fast_call(self, data, x, final_subs=None):
    if self.is_float and not hasattr(x, 'dims'):
        xp = data['lookup_dim'].values
        fp = np.asarray(data.values, dtype=float)
        return float(np.interp(float(x), xp, fp))
    return _orig_call(self, data, x, final_subs)
lookups.HardcodedLookups._call = _fast_call

MODEL = '/home/hatch/workspace/icorrupt-refresh/model/model_2026_recalibrated.mdl'
OUTDIR = '/home/hatch/workspace/icorrupt-refresh/model/scenarios_v2'

INDICATORS = [
    'Trust In Government',
    'Middle Class Contributions Under $200',
    'Elite Contributions Over $2700',
    'Elite to Middle Class Contribution Ratio',
    'Total Spending on Lobbyists',
    'Ratio Top 5 Percent to Middle Class',
]

SCENARIOS = {
    'baseline': {},
    'finance': {
        'voucher policy amount per voter': 35,
        'public funding match dollar multiplier': 9,
        'cost control rate': 0.001,
    },
    'leverage': {
        'sunshine laws multiplier after repeal': 1.0,
    },
    'everything': {
        'voucher policy amount per voter': 35,
        'public funding match dollar multiplier': 9,
        'cost control rate': 0.001,
        'sunshine laws multiplier after repeal': 1.0,
    },
}

def run_scenario(name, params):
    print(f"=== {name} ===", flush=True)
    model = pysd.read_vensim(MODEL)
    result = model.run(params=params, return_columns=INDICATORS) if params else model.run(return_columns=INDICATORS)
    result.to_csv(f"{OUTDIR}/{name}.csv")
    row = result[result.index >= 2060].iloc[0]
    print(f"  2060 Trust={row['Trust In Government']:.1f} Ineq={row['Ratio Top 5 Percent to Middle Class']:.2f}", flush=True)
    return result

if __name__ == '__main__':
    os.makedirs(OUTDIR, exist_ok=True)
    for name, params in SCENARIOS.items():
        run_scenario(name, params)

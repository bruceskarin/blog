# Group A — Campaign Finance Data Sources and Methodology

**Access date**: October 9–10, 2026  
**Coverage**: 2000–2024 election cycles (full backfill completed 2026-10-10)

**Completion status** (as of 2026-10-10):
- ✅ Complete (2000–2024): A1, A2, A3, A4, A5, A6, A7, A8, A9, A10 — all ten CSVs span 2000–2024
- 2014–2024 computed by prior workers (see below); 2000–2012 backfilled via `work/fec/compute_backfill.py`
- Backfill values (2000–2012):

| Cycle | A2 ($M) | A3 ($M) | A4 ($M) | A5 ($M) | A6 ($M) | A7 | Threshold |
|-------|---------|---------|---------|---------|---------|-----|-----------|
| 2000 | 357 | 43.0 | 6.8 | 161.7 | 145.6 | 0.16 | $2,000 |
| 2002 | 407 | 46.2 | 9.7 | 186.9 | 164.3 | 0.21 | $2,000 |
| 2004 | 476 | 42.1 | 59.3 | 203.0 | 172.1 | 1.41 | $2,300 |
| 2006 | 545 | 34.4 | 80.7 | 238.6 | 191.4 | 2.35 | $2,300 |
| 2008 | 600 | 43.4 | 86.9 | 265.1 | 204.3 | 2.00 | $2,300 |
| 2010 | 615 | 60.0 | 93.9 | 248.6 | 212.8 | 1.56 | $2,500 |
| 2012 | 685 | 40.0 | 129.3 | 286.1 | 229.8 | 3.24 | $2,500 |

- Identity A3+A4+A5+A6=A2 verified for all 13 cycles (2000–2024)
- 2014–2024 A4 values (from prior work):
  - 2014: $147,621,174 (t=$2,700); 2016: $171,214,926 (t=$2,700; 295,456 donors)
  - 2018: $151,865,530 (t=$2,700; 409,458 donors); 2020: $215,560,806 (t=$2,800; 576,130 donors)
  - 2022: $272,006,132 (t=$2,900; 638,394 donors); 2024: $214,583,722 (t=$3,300; 593,337 donors)
- Download notes: FEC bulk `indiv` zips for 2020/2022/2024 are 4.2–5.9GB; all truncated on first download via fec.gov redirect (curl exit 18) and were resumed from S3. Backfill zips (2000–2012) also truncated initially; resumed via S3 `Accept-Ranges` to full size, verified with `zipfile.testzip`.
- ⚠️ A8 lobbying-source seam: the 2016 A8 row ($7,124,887,275) was computed with ~$6.88B 2015–2016 lobbying, while 2018–2024 use the B2 CSV series (2015+2016=$6.35B → would give A8_2016=$6,594,887,275). Recommend recomputing the 2016 A8 row with B2 for series consistency — parent decision.
- Key finding: A7 (elite/middle ratio) collapsed from 3.54 (2016) to ~1.0 (2020–2024) — small-dollar surge; elite donors no longer dominate winning House campaign receipts the way the 2015 paper described.

## Overview

All campaign finance variables (A1–A6, A9) are derived from Federal Election Commission (FEC) bulk data and the FEC API. Lobbying data for A8 comes from OpenSecrets. All values are in nominal dollars.

## Variables

### A1 — Total Campaign Expenditures (all House candidates)
- **Source**: FEC bulk data, `weball{yy}.zip` (Candidate Summary file)
- **URL**: https://www.fec.gov/files/bulk-downloads/20{yy}/weball{yy}.zip
- **Method**: Sum of `TTL_DISB` (total disbursements) over all House candidates in the cycle. House candidates identified via `cn{yy}.zip` (Candidate Master file), filtering to `CAND_OFFICE='H'` and `CAND_ELECTION_YR={yyyy}`.
- **Definition change**: None. Same as original (total House disbursements per cycle).

### A2 — Total Contributions for Winning Campaigns
- **Source**: FEC bulk data, `weball{yy}.zip`
- **Method**: For each winning House candidate (see Winners section below), sum `TTL_INDIV_CONTRIB` + `OTHER_POL_CMTE_CONTRIB` + `POL_PTY_CONTRIB` + `CAND_CONTRIB`. This matches the FEC's "contributions" definition.
- **Definition change**: None. Same as original.

### A3 — Individual Contributions Under $200 (unitemized)
- **Source**: FEC API, `/v1/candidate/{candidate_id}/totals/` endpoint
- **URL**: https://api.open.fec.gov/v1/candidate/{id}/totals/?cycle={yyyy}&full_election=true
- **Method**: Sum of `individual_unitemized_contributions` over all winning House candidates per cycle. Validated against residual method (weball TTL_INDIV_CONTRIB minus API individual_itemized_contributions) on 2014 sample — matches exactly.
- **Definition change**: None. Same as original (unitemized <$200).

### A4 — Elite Contributions Over Threshold
- **Source**: FEC bulk data, `indiv{yy}.zip`
- **Method**: Transaction-level aggregation. For each winner's committees (all committees linked via `ccl{yy}.zip`, not just principal), aggregate individual contributions by donor (`NAME` + `ZIP_CODE`) per committee. Sum donor totals exceeding the cycle threshold.
- **Thresholds** (FEC individual contribution limits per cycle):
  - 2014: $2,700 (used for validation; matches original's fixed cut)
  - 2016: $2,700
  - 2018: $2,700
  - 2020: $2,800
  - 2022: $2,900
  - 2024: $3,300
- **Comparability**: The original 1990–2014 series used a fixed $2,700 cut. For 2016–2024, the threshold tracks the actual FEC legal limit, so "elite" consistently means "donors giving at/near the legal maximum." The 2016 and 2018 limits were $2,700, identical to the original cut.
- **Definition change**: Threshold varies by cycle (see above) vs. fixed $2,700 in original.

### A5 — PAC Contributions
- **Source**: FEC bulk data, `weball{yy}.zip`
- **Method**: Sum of `OTHER_POL_CMTE_CONTRIB` + `POL_PTY_CONTRIB` over winning House candidates.
- **Definition change**: None. Same as original.

### A6 — All Other Contributions (remainder)
- **Source**: Derived
- **Method**: `A6 = A2 - A3 - A4 - A5`. Represents itemized individual contributions between $200 and the elite threshold, plus candidate self-contributions.
- **Definition change**: None. Same as original.

### A7 — Elite to Middle Class Contribution Ratio
- **Source**: Derived
- **Method**: `A7 = A4 / A3`
- **Definition change**: None.

### A8 — Elite Political Investment per Congress
- **Source**: Derived from A4, A5 + OpenSecrets lobbying data
- **Method**: `A8 = (A4 + A5) / 2 + (2-year lobbying total)`. The 2-year lobbying total is the sum of annual federal lobbying spending for the two calendar years of the election cycle (e.g., 2023+2024 for the 2024 cycle).
- **Lobbying source**: OpenSecrets (Center for Responsive Politics), federal lobbying spending totals.
  - URL: https://www.opensecrets.org/federal-lobbying
  - Annual totals: 2015–2016: ~$6.88B (derived); 2017: $3.3B; 2018: $3.42B; 2019: $3.4B; 2020: $3.5B; 2021: $3.8B; 2022: $4.1B; 2023: $4.2B; 2024: $4.4B
- **Definition change**: None. Same formula as original xlsx ("Total Elite Investment" sheet).

### A9 — Number of House Candidates
- **Source**: FEC bulk data, `weball{yy}.zip` + `cn{yy}.zip`
- **Method**: Count of distinct `CAND_ID` in weball for House candidates (filtered via cn to `CAND_OFFICE='H'` and `CAND_ELECTION_YR={yyyy}`).
- **Definition note**: This counts all filers with financial activity, including primary candidates. The original's 2012 value (784) appears to use a narrower definition (possibly general-election candidates only). Our values are higher (1,400–2,300) due to this broader definition.
- **Definition change**: Broader than original (includes all primary filers).

### A10 — Mean Campaign Expenditure per Candidate
- **Source**: Derived
- **Method**: `A10 = A1 / A9`
- **Definition change**: None.

## Winners Identification

Winning House candidates per cycle identified from:

- **2014–2022**: FEC official election results files ("Federal Elections" series)
  - 2014: https://www.fec.gov/resources/cms-content/documents/federalelections2014.xls
  - 2016: https://www.fec.gov/resources/cms-content/documents/federalelections2016.xlsx
  - 2018: https://www.fec.gov/resources/cms-content/documents/federalelections2018.xlsx
  - 2020: https://www.fec.gov/resources/cms-content/documents/federalelections2020.xlsx
  - 2022: https://www.fec.gov/resources/cms-content/documents/federalelections2022.xlsx
  - Method: "GE WINNER INDICATOR" column. Non-voting delegates (DC, PR, GU, VI, AS, MP) excluded.
  - Corrections: FEC file typos fixed (verified via FEC API): 2022 FL-26, IN-06, IN-07; 2014 IL-02 (Robin Kelly). Louisiana "W (Runoff)" treated as winner. 2014 HI-01 (no indicator; highest votes used). 2018 NC-09 omitted (election invalidated, no certified winner).
- **2024**: unitedstates/congress-legislators `legislators-current.yaml` (119th Congress) + manual verification
  - URL: https://raw.githubusercontent.com/unitedstates/congress-legislators/main/legislators-current.yaml
  - 13 seats missing from YAML resolved via FEC API + House Clerk 2024 election statistics
  - 3 winners (MD-04, TX-03, VA-05) confirmed by Clerk but missing from FEC bulk data; omitted (see Gaps)
- **2004–2012**: FEC "Federal Elections" .xls files
  - 2012: GE WINNER INDICATOR column ('W'); CT fusion-voting duplicates deduped by FEC ID; Senate rows excluded
  - 2004/2006/2008/2010: no winner indicator column; winner = highest GENERAL votes per (state, district); Louisiana jungle-primary handled via general votes
  - Corrections: 2008 NC-05 — file listed Price's ID (H6NC04037) for Foxx; corrected to H4NC05146 via FEC API
- **2000, 2002**: unitedstates/congress-legislators (107th/108th Congress rosters) + FEC candidate master files
  - Members with House terms starting Jan 2001 (107th, elected 2000) / Jan 2003 (108th, elected 2002)
  - 17 (2002) / 12 (2000) missing FEC IDs resolved via cn02/cn00 name matching
  - 2000 CA-32: Diane Watson (H2CA32099, special election winner after Dixon's death)

## 2000–2012 Backfill Methodology

Computed via `work/fec/compute_backfill.py` using the same logic as 2014–2024:
- **A1/A2/A5/A9**: from `weball{yy}.txt` (field indices 7=TTL_DISB, 17=TTL_INDIV, 25=OTHER_POL_CMTE, 26=POL_PTY, 11=CAND_CONTRIB; verified identical for 2000 old-format file via FEC API spot-check)
- **A3**: `TTL_INDIV_CONTRIB` (weball) minus itemized IND contributions (indiv file) for winner committees
- **A4**: donor aggregation (NAME+ZIP5 per committee), sum of totals strictly exceeding threshold; IND only, txn types 15*
- **Thresholds**: 2000/2002: $2,000 (pre-BCRA $1,000/election); 2004/2006/2008: $2,300 (BCRA era); 2010/2012: $2,500
- **A6/A7/A8/A10**: derived (A6=A2−A3−A4−A5; A7=A4/A3; A8=(A4+A5)/2+2yr lobbying; A10=A1/A9)
- **A8 lobbying**: 2-year OpenSecrets sums from original workbook (1999+2000=$3.02B; 2001+02=$3.47B; 2003+04=$4.25B; 2005+06=$5.07B; 2007+08=$6.17B; 2009+10=$7.02B; 2011+12=$6.64B)
- **Format handling**: 2000/2002/2006 indiv files use pre-2002 FEC format (ENTITY_TP empty, no MEMO_CD); 2004/2008/2010/2012 use new format. Script auto-detects per file.

## Data Quality Notes (backfill)

1. **A3 residual inflation (2000–2012)**: A3 is computed as weball TTL_INDIV minus bulk-file itemized. Early-cycle bulk indiv files are less complete (paper filings, imperfect electronic compliance), so itemized is undercounted and the residual A3 overestimated. 2000–2012 A3 ($34–60M) vs 2014 ($7.9M, from near-complete filings) illustrates this. Treat pre-2014 A3 levels as upper bounds; the *trend* is more reliable than absolute levels.
2. **A4 undercount (2000–2012)**: correspondingly, elite contributions from incomplete itemized files are lower bounds.
3. **2012→2014 seam**: A3 drops $40M→$7.9M reflecting filing-completeness improvement, not a real fundraising collapse. Document when calibrating.
4. **2000/2002 thresholds**: $2,000 = pre-BCRA per-cycle max ($1,000×2 elections); strictly-over threshold captures only donors exceeding the legal max, hence low A4 values ($6.8M/$9.7M).

## Gaps and Limitations

1. **2014 validation**: Our methodology reproduces the original's A2–A6 approximately but not exactly. Specifically, our A5 (PAC) is ~29% lower than the original's 2014 value ($299M vs $419M), and our A3/A4 split differs. Possible causes: (a) FEC data revisions between 2015 (original) and 2024 (our download); (b) undocumented methodology choices in original (e.g., OpenSecrets processing vs. direct FEC bulk). Our 2016–2024 series is internally consistent.
2. **2024 missing winners**: MD-04 (Glenn Ivey), TX-03 (Keith Self), VA-05 (John McGuire) won per House Clerk but are absent from FEC bulk/API (likely paper filers). Omitted from 2024 winners (432/435).
3. **2018 NC-09**: No certified winner (election invalidated). Omitted (434 winners).
4. **A9 definition**: Broader than original (all filers vs. likely general-election only).
5. **Winners missing from weball**: 3–6 per cycle (low-activity filers or ID mismatches); impact <1.5% of winners.

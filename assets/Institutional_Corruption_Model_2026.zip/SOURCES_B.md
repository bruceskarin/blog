# Group B — Data Sources & Methodology Notes

Access date for all sources: **2026-10-09**.

Continuity anchors from the original workbook (Lobbyists sheet / `calibration_data.dat`):
2014 = 11,800 registered lobbyists / $3.24B lobbying spending; last trust observation 2014.0833 → 24%.

---

## B1 — Registered Lobbyists (`B1_registered_lobbyists.csv`)

**Definition:** Number of registered federal lobbyists per year (OpenSecrets lobbying database, built from Senate Office of Public Records LDA filings).

**Status: PARTIAL — 4 of 10 years (2015, 2016, 2017, 2022). Gaps: 2018, 2019, 2020, 2021, 2023, 2024.**

| Year | Value | Source |
|------|-------|--------|
| 2015 | 11,465 | OpenSecrets, "For lobbying, gravity's pull continues, floor not found yet" (Jan 2016) |
| 2016 | 11,169 | OpenSecrets, "Drain the swamp? Lobbyists are filling it up" (Jan 2018) |
| 2017 | 11,444 | OpenSecrets, "Drain the swamp? Lobbyists are filling it up" (Jan 2018) |
| 2022 | 12,609 | OpenSecrets, "Federal lobbying spending reaches $4.1 billion in 2022, the highest since 2010" (Jan 2023) |

Source URLs:
- https://www.opensecrets.org/news/2016/01/for-lobbying-gravitys-pull-continues-floor-not-found-yet/
- https://www.opensecrets.org/news/2018/01/drain-the-swamp-lobbyists-are-filling-it-up
- https://www.opensecrets.org/news/2023/01/federal-lobbying-spending-reaches-4-1-billion-in-2022-the-highest-since-2010

**Methodology notes:**
- OpenSecrets derives the annual count from individual lobbyists listed on LD-2 filings; the count is of *unique registered lobbyists active in that year*.
- **2016 judgment call:** two OpenSecrets articles give different 2016 counts — 11,143 (Feb 2017 article, "Lobbying poised to shoot up with Trump") vs 11,169 (Jan 2018 article). The later figure reflects late/amended filings and is used here (revisions of +26 are consistent with OpenSecrets' practice of updating prior-year counts).
- **Small discontinuity vs. original series:** the original workbook's 2014 = 11,800 and 2010 = 12,948 differ slightly from what these articles imply for adjacent years (e.g., the Jan 2016 article cites 2010 = 12,945). This is normal OpenSecrets revision drift from late filings; no adjustment made.
- **Gaps (2018, 2019, 2020, 2021, 2023, 2024):** OpenSecrets' year-end articles for these years did not publish an annual lobbyist headcount, and no other primary source with the identical OpenSecrets counting methodology was found. Values are omitted, not estimated. The Senate Office of Public Records raw filing data or OpenSecrets bulk data could fill these in a follow-up.

---

## B2 — Total Spending on Lobbyists, $/Year (`B2_lobbying_spending.csv`)

**Definition:** Total reported federal lobbying spending per calendar year, nominal dollars, from OpenSecrets (Center for Responsive Politics) aggregation of LDA filings.

**Status: COMPLETE — 2015–2024.**

| Year | Value (nominal $) | Source |
|------|-------------------|--------|
| 2015 | 3,200,000,000 | OpenSecrets (Jan 2016) |
| 2016 | 3,150,000,000 | OpenSecrets (Feb 2017) |
| 2017 | 3,370,000,000 | OpenSecrets (Jan 2018) |
| 2018 | 3,420,000,000 | OpenSecrets (Jan 2019) |
| 2019 | 3,470,000,000 | OpenSecrets (Jan 2020) |
| 2020 | 3,500,000,000 | OpenSecrets (Jan 2021): "nearly reached $3.5 billion" — least precise year in series |
| 2021 | 3,700,000,000 | OpenSecrets via Washington Post (Mar 2022): "broke $3.7 billion," +6% over 2020 |
| 2022 | 4,100,000,000 | OpenSecrets (Jan 2023) |
| 2023 | 4,270,000,000 | Statista chart citing OpenSecrets (Jul 2025) |
| 2024 | 4,440,000,000 | Statista chart citing OpenSecrets (Jul 2025) |

Source URLs:
- 2015: https://www.opensecrets.org/news/2016/01/for-lobbying-gravitys-pull-continues-floor-not-found-yet/
- 2016: http://www.opensecrets.org/news/2017/02/lobbying-poised-to-shoot-up-with-trump/
- 2017: https://www.opensecrets.org/news/2018/01/drain-the-swamp-lobbyists-are-filling-it-up
- 2018: https://www.opensecrets.org/news/2019/01/lobbying-spending-reaches-3-4-billion-in-18
- 2019: https://www.opensecrets.org/news/2020/01/lobbying-spending-in-2019-near-all-time-high/
- 2020: http://www.opensecrets.org/news/2021/01/lobbying-spending-nears-record-high-in-2020-amid-pandemic
- 2021: https://www.opensecrets.org/news/2022/03/federal-and-state-lobbying-spending-soared-to-10-billion-during-the-2020-election-cycle-but-state-lobbying-disclosure-remains-limited/
- 2022: https://www.opensecrets.org/news/2023/01/federal-lobbying-spending-reaches-4-1-billion-in-2022-the-highest-since-2010
- 2023: https://www.OpenSecrets.org/news/2024/01/state-and-federal-lobbying-spending-tops-46-billion-after-federal-lobbying-spending-broke-records-in-2023 ("$4.2 billion"; exact $4.27B from Statista)
- 2024: https://WWW.Opensecrets.org/news/2025/02/federal-lobbying-set-new-record-in-2024 ("$4.4 billion"; exact $4.44B from Statista)
- Statista (exact 2023/2024 figures): https://www.statista.com/statistics/257337/total-lobbying-spending-in-the-us/

**Methodology notes / decisions:**
- **Nominal dollars throughout**, consistent with the original 1998–2014 series (which is nominal; e.g., 2014 = $3.24B). Precision matches the original ($10M).
- **Rejected:** OpenSecrets' "Layers of Lobbying" report (June 2022) gives exact 2015–2020 figures, but they are *inflation-adjusted* dollars — incompatible with the nominal series. Not used.
- **Rejected:** Bloomberg Government's $4.5B (2024) / $4.35B (2023) figures — different methodology (includes estimated non-LDA spending). OpenSecrets kept for series consistency.
- 2023/2024 exact figures ($4.27B/$4.44B) come from Statista's chart, which cites OpenSecrets as its source; OpenSecrets' own articles round to $4.2B/$4.4B. Flagged as secondary-but-sourced.
- 2020 is the least precise observation ("nearly reached $3.5 billion"); recorded as $3.5B.

---

## B3 — Trust in Government, percent (`B3_trust_in_government.csv`)

**Definition:** % of U.S. adults saying they trust "the government in Washington to do what is right" *just about always* or *most of the time*.

**Status: COMPLETE as observations — 10 surveys, 2015–2024. No observations found for 2016 or 2018.**

**Exact question wording** (confirmed from Pew toplines; unchanged across the whole 1958–2024 series):
> "How much of the time do you think you can trust the government in Washington to do what is right? Just about always, most of the time, or only some of the time?"
> Trust = "Just about always" + "Most of the time". (Volunteered "Never" also recorded.)

**Source:** Pew Research Center, "Public Trust in Government: 1958-2025" — the same series as the original 1958–2014 data (earlier edition of this page). URL: https://pewresearch.org/politics/2025/12/04/public-trust-in-government-1958-2025/

**Methodology notes:**
- **Series continuity confirmed:** same indicator, same question, same chart definition as the 1958–2014 edition. Pre-2015 observations on this page splice Pew, National Election Studies, Gallup, ABC/Washington Post, CBS/New York Times, and CNN — identical source mix to the original series. No methodology break is flagged by Pew.
- **Survey mode change (documented, no break flagged):** through ~2020 Pew used RDD telephone surveys; from 2020 on the observations come from Pew's online American Trends Panel (probability-based). Pew publishes a "phone trend for comparison" showing the two modes track closely, and presents the series as continuous. The page's published values are used as-is.
- **Date convention — DEVIATION FROM SPEC:** the spec asks for integer years, but the original `calibration_data.dat` records each trust observation at a **fractional decimal year** (e.g., 2014.0833 → 24), with multiple observations per year. This CSV preserves that format so the observations can be appended directly; annualizing is left to the modeler (the reverse transformation would be impossible). Decimal year = year + (day-of-year − 1) / (365 or 366), using the field-period end date published on the Pew page. Note the original file's own convention is not fully self-consistent (e.g., 2014.0833 ≈ month-based), so an exact match to its convention is not achievable; the convention used here is documented and precise.
- **Values** are whole-number percents, matching the `.dat` convention (77 = 77%).
- **Rounding:** page values used as published (e.g., 4/12/2020 = 27; 5/01/2022 = 20; 5/19/2024 = 22). Underlying toplines sum to ±1 point in three cases due to rounding of unrounded percentages; the published series values are authoritative.
- **Gaps:** Pew's page lists no trust observations for 2016 or 2018 (the next observation after 12/04/2017 is 3/25/2019). Omitted, not interpolated. All post-2015 observations on the page are Pew surveys (no CNN/CBS/NYT/Gallup readings after 2014, unlike the pre-2015 stretch).

| Survey (field end) | Decimal year | % trust |
|---|---|---|
| 10/04/2015 | 2015.756164 | 19 |
| 4/11/2017 | 2017.273973 | 20 |
| 12/04/2017 | 2017.923288 | 18 |
| 3/25/2019 | 2019.227397 | 17 |
| 4/12/2020 | 2020.278689 | 27 |
| 8/02/2020 | 2020.584699 | 20 |
| 4/11/2021 | 2021.273973 | 24 |
| 5/01/2022 | 2022.328767 | 20 |
| 6/11/2023 | 2023.441096 | 16 |
| 5/19/2024 | 2024.379781 | 22 |

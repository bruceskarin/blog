# Sources — Group C (Voters + Income + Tax)

Access date for all sources: 2026-10-09. All dollar values are nominal (current) dollars.
Original series (through 2013/2014) preserved from `calibration_data.dat`; new years appended.
No values were fabricated; every appended value comes from the cited source table.

## C1 Voting Age Population, C2 Registered Voters, C3 Voter Turnout, C4 Voter Percentages

**Source:** U.S. Census Bureau, Current Population Survey (CPS) Voting and Registration Supplement —
"Historical Time Series Tables" (voting-historical-time-series).
- Table A-7. Reported Voting Rates in Congressional Election Years: November 1966 to 2022
  (total voting-age population, total voted, percent voted — numbers in thousands)
- Table A-8. Reported Registration Rates in Congressional Election Years: November 1966 to 2022
  (total registered, percent registered — numbers in thousands)
- Landing page: https://www.census.gov/data/tables/time-series/demo/voting-and-registration/voting-historical-time-series.html
- Files: https://www2.census.gov/programs-surveys/cps/tables/time-series/voting-historical-time-series/hst_vote07.xlsx
  and .../hst_vote08.xlsx

**Methodology notes:**
- Midterm congressional election years only (1962–2022); 2024 is a presidential year and is excluded per spec.
- Values are CPS survey estimates (weighted reports of voting behavior), NOT administrative vote counts;
  CPS overstates turnout by ~5–10 points vs. ballots counted. Consistent with the original series.
- 2014 row REPLACED: the original file's 2014 values came from an early/odd vintage
  (VAP 245,712,915; voted = VAP × 35.9% = 88,210,936; registered missing). Replaced with the current
  Census table vintage: VAP 239,874,000; voted 92,251,000; registered 142,166,000. Pre-2014 values kept
  as in the original (VAP matches the current tables exactly; voted/registered differ by <0.1% due to
  later Census revisions — immaterial for calibration).
- 1962 VAP (109,680,000) retained from the original (Census 1962 Current Population Reports);
  current A-tables begin at 1966.
- Comparability break: before 1972 the voting age was 21+ in most states; the 26th Amendment (1972)
  lowered it to 18. Affects 1962/1966/1970 vs. later years (Census footnote on Table A-7).
- C4 (`year,percent_registered,percent_turnout`) uses the Census published percents; percent_registered
  is blank before 1966 (registration not collected).

## C5 Households

**Source:** U.S. Census Bureau, CPS Annual Social and Economic Supplement (ASEC) —
"Historical Income Tables: Households," Table H-1AR, "Number of Households" column (thousands → persons).
- Landing page: https://www.census.gov/data/tables/time-series/demo/income-poverty/historical-income-households.html
- File: https://www2.census.gov/programs-surveys/cps/tables/time-series/historical-income-households/h01ar.xlsx
- Table title: "Limits for Household Income Quintiles and Top 5 Percent of All Households: 1967 to 2025"

**Methodology notes:** Household = all people occupying a housing unit (CPS ASEC, as of March of the
following year). 1967/2000/2010 spot-checked against the original series (<0.05% difference — same series,
later vintage). Original 1967–2013 kept; 2014–2024 appended. 2025 data exists in the table but the spec
target is 2024.

## C6 Quintile Mean Income, C7 Top 5% Mean Income

**Source:** U.S. Census Bureau, CPS ASEC — "Historical Income Tables: Households," Table H-3AR,
"Mean Household Income Received by Income Quintile and Top 5 Percent of All Households," **Current Dollars** section.
- File: https://www2.census.gov/programs-surveys/cps/tables/time-series/historical-income-households/h03ar.xlsx

**Methodology notes:**
- Money income concept: pretax cash income; excludes in-kind transfers and capital gains subtleties per CPS.
- Original 1967 values match the current table exactly (1600/4433/7077/9902/17820/28110) — same series.
- Original 2013 used the traditional-questionnaire vintage (footnote 38); the table also carries a
  redesigned-questionnaire 2013 row (footnote 39) which was NOT used, preserving continuity.
- Known CPS breaks documented in Census footnotes, carried forward in the series: 2013 redesigned income
  questions; 2017 updated processing system; 2020 flagged for COVID nonresponse bias; 2022 switch to
  C-CPI-U inflation adjustment (current-dollar values unaffected); 2024 flagged for Vintage 2025
  population controls (footnote 42 — minor).
- C8 (`year,value`) = C7 / C6-middle, rounded to 1 decimal — verified identical to the original
  "Ratio Top 5 Percent to Middle Class" definition (matches .dat to 0.1).

## C9 Top Decile Marginal Income Tax Rate

**Source:** Tax Policy Center, "Historical Highest Marginal Income Tax Rates" (1913–2026, updated 2026-09-29).
- https://www.taxpolicycenter.org/statistics/historical-highest-marginal-income-tax-rates
- Post-2013 values verified against IRS: 39.6% for 2013–2017 (American Taxpayer Relief Act of 2012);
  37% from 2018 (Tax Cuts and Jobs Act) — see IRS IR-2018-94:
  https://www.irs.gov/newsroom/inflation-adjustments-under-recently-enacted-tax-law

**Methodology notes:** Top statutory federal marginal rate on ordinary income, rounded to the nearest
integer to match the original convention (e.g., 39.6 → 40, as the original did for 1993–2000 and 2013).
Appended: 2014–2017 = 40; 2018–2024 = 37. Note: the TPC page itself was confirmed live on 2026-10-09 but
its download sat behind a bot check for automated fetch, so the 2014–2024 statutory values above were
cross-verified against the IRS release; the pre-2014 series is unchanged from the original.

## C10 Top Decile Income Share

**Source:** Emmanuel Saez (UC Berkeley), "The Evolution of Top Incomes in the United States
(Updated with 2024 estimates)," June 2026 — data file TabFig2024.xlsx, **Table A3:
"Top fractiles income shares (including capital gains)," P90-100**.
- Paper: https://eml.berkeley.edu/~saez/saez-UStopincomes-2024.pdf
- Data: https://eml.berkeley.edu/~saez/TabFig2024.xlsx

**Methodology notes:** Income concept = fiscal (tax-return) income from IRS Statistics of Income,
INCLUDING realized capital gains; fractiles defined by total income including capital gains — matches the
original 1960–2011 series (e.g., 2011: 48.2). Rounded to 1 decimal. The 2024 vintage revises 2011
48.2 → 48.1; original 1960–2011 values kept, 2012–2024 appended. Note the series is volatile around
capital-gains realizations (record 55.6% in 2021, vs. 48.3% excluding gains in 2024).

## Gaps

None. All target years are filled: C1–C4 through 2022 (midterms), C5–C10 through 2024.
2025 income/voting data exists at the sources but was outside the spec'd target horizon.

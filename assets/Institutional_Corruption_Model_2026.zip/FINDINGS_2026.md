# 2026 Update: Key Findings

## Data corrections

### The "233x" ratio was wrong
The 2015 paper claimed elite donors ($2700+) gave 233x what small donors (under $200) gave in 2014. The underlying "under $200" data was undercounted ~11x due to flawed OpenSecrets curation.

**Corrected 2014:**
- Under $200: $7.9M (was $0.7M)
- Elite-to-small ratio: **18.6x** (was 233x)

**The real story 2014-2024:**
- 2014: 18.6x
- 2016: 3.5x
- 2018: 1.5x
- 2020: 0.9x (small donors OUTGAVE elites)
- 2022: 1.2x
- 2024: 1.1x

Small-dollar fundraising exploded with ActBlue/online platforms. By 2020, small donors contributed more to winning House campaigns than max-out elite donors.

### Other methodology notes
- **PAC contributions**: Original overcounted ~40% (2014: $419M → $300M corrected). Likely included non-House or broader committee universe.
- **Candidate counts**: Original used narrow definition (2012: 784). New uses all filers (2016: 1,457). Broader definition is more accurate for "number of campaigns."
- **Elite contributions**: Reasonably close (2014: $167M → $148M, -12%).

## Model implications

### Small-dollar sector needs structural redesign
The 2015 model's middle-class contribution mechanism shows negative correlation (-0.45) with corrected data. It was fitted to the flawed low values and doesn't capture the online fundraising revolution.

The model needs a new structure for:
1. Online/small-dollar fundraising growth (exogenous tech driver, 2004-2024)
2. The shift from elite-dominated to small-donor-competitive fundraising

### Policy retests required
1. **9:1 small-dollar match**: 2015 found it "completely ineffective." With the corrected baseline (small donors now competitive), this MUST be retested. The conclusion may flip.
2. **Vouchers**: $25 (2015) → ~$35 (2026 dollars). Participation assumptions need review given demonstrated small-donor willingness.
3. **Outside spending**: Post-Citizens United dark money not in 2015 model. Consider adding as a policy lever (disclosure requirements, caps).

### Trust dynamics hold up
Trust in Government: model MAPE 29%, correlation 0.59. The core trust→engagement→policy feedback loops are structurally sound, just need parameter tuning with extended data.

## Narrative shifts for the rewrite

### What changes
1. **The villain is not just elite donors anymore.** Small donors now match elites in House races. The corruption dynamic has shifted from "elites buy access" to "everyone is fundraising constantly, and the time/money chase itself distorts representation."
2. **The 233x stat is dead.** Replace with the true story: 19x in 2014 collapsing to ~1x by 2020. This is actually a MORE interesting story — it shows how quickly the system changed.
3. **Policy optimism**: If small donors can compete, then reforms that amplify small donors (matching, vouchers) have more leverage than the 2015 model suggested.

### What stays
1. **The core feedback loops**: Money → policy bias → inequality → distrust → disengagement → more money influence. This is still the heart of the story.
2. **The trust collapse**: 77% (1960s) → 20% (2020s). The data confirms the trend.
3. **Lobbying growth**: $3.2B (2015) → $4.4B (2024). The influence industry keeps growing.

## Open questions
1. Should the model add an explicit "online fundraising technology" driver?
2. How to handle 1990-1999 campaign finance (pre-electronic filing era)?
3. Outside spending: add as a stock, or note as limitation?
4. Which new reform proposals to test (e.g., DISCLOSE Act, Seattle-style vouchers at scale)?

# Sources — Group D (Legislative + Federal Register + GDP)

All data collected 2026-10-09. No values fabricated; gaps are omitted, not imputed.

## D1 — Bills Passed per congress (`D1_bills_passed.csv`)

- **Source:** Brookings Institution, *Vital Statistics on Congress*, Table 6-1
  "House Workload, 80th–118th Congresses, 1947–2024", column "Bills passed".
- **URL:** https://www.brookings.edu/wp-content/uploads/2026/04/6-1-Full.pdf
- **Coverage:** 1950–2024 at even years (Congress end-year). 1950–2012 carried
  from the original workbook (verified identical to current Table 6-1 for every
  overlapping year).
- **Methodology notes:**
  - "Bills passed" = bills and joint resolutions passed by the House per
    Congress (per table footnote a).
  - **2014 (113th Congress) corrected:** the original workbook used 223, which
    was the *first-session-only* preliminary figure from the April-2014 edition
    of Vital Statistics. The final two-session figure is **682**. Using 682.
  - New values: 2016: 896, 2018: 1,162, 2020: 924, 2022: 887, 2024: 777.

## D2 — Bills Enacted per congress (`D2_bills_enacted.csv`)

- **Source:** Brookings Institution, *Vital Statistics on Congress*, Table 6-4
  "Congressional Workload, 80th–118th Congresses, 1947–2024", column
  "No. of bills enacted" (public bills).
- **URL:** https://www.brookings.edu/wp-content/uploads/2026/04/6-4-Full.pdf
- **Coverage:** 1950–2024 at even years. 1950–2012 carried from the original
  workbook (verified identical to current Table 6-4 for every overlapping year).
- **Methodology notes:**
  - New values: 2014: 296, 2016: 329, 2018: 442, 2020: 344, 2022: 362, 2024: 274.
  - Cross-checked against GovTrack's legislation statistics (enacted counts
    match: 118th = 274, 117th ≈ 362–365, 116th = 344, 115th ≈ 442–443,
    114th = 329, 113th = 296).

## D3 — Total Pages of Statutes per congress (`D3_statute_pages.csv`)

- **Source:** Same Brookings Table 6-4 as D2, column "Total pages of statutes"
  (pages in the *Statutes at Large*).
- **URL:** https://www.brookings.edu/wp-content/uploads/2026/04/6-4-Full.pdf
- **Coverage:** 1950–2024 at even years.
- **Methodology notes:**
  - **2012 (112th Congress) corrected:** the original workbook used 2,495 pages
    (the preliminary figure from the 2013/2014 Vital Statistics editions,
    published before the 112th's *Statutes at Large* were complete). Brookings
    revised this to **4,415** in the 2019 edition and all later editions
    (verified stable across the 2019, 2024, and 2026 editions). Using 4,415.
    This removes a spurious dip at 2012 that would distort calibration.
  - New values: 2014: 5,289, 2016: 6,170, 2018: 7,872, 2020: 8,432,
    2022: 8,742, 2024: 4,350.

## D4 — Average Pages Per Statute per congress (`D4_avg_pages_per_statute.csv`)

- **Derived:** D3 / D2, rounded to 2 decimals (matches Brookings' published
  "Average pages per statute" column; verified: 2012 = 15.60, 2024 = 15.88).
- No separate source.

## D5 — Number of Pages in the Federal Register (`D5_federal_register_pages.csv`)

- **Source:** Brookings Institution, *Vital Statistics on Congress*, Table 6-5
  "Pages in the Federal Register, 1936–2024" (underlying source: Office of the
  Federal Register).
- **URL:** https://www.brookings.edu/wp-content/uploads/2026/04/6-5-Full.pdf
- **Coverage:** Annual 1966–2024, plus the original workbook's extra points for
  1946 and 1956. 1966–2013 carried from the original workbook (verified
  identical to current Table 6-5 for every overlapping year).
- **Methodology notes / gaps:**
  - **1967, 1968, 1970 are missing** — not reported in Brookings Table 6-5
    (same gap as the original series). Omitted, not imputed.
  - 2017 was revised 61,950 → 61,703 between editions; using the latest figure.
  - New values: 2014: 78,796, 2015: 81,402, 2016: 97,069, 2017: 61,703,
    2018: 67,593, 2019: 72,566, 2020: 87,349, 2021: 74,532, 2022: 80,757,
    2023: 90,402, 2024: 107,262 (new all-time high).
  - Counting-methodology caveat: page totals differ slightly across publishers
    (e.g., 2016: Brookings 97,069 vs. Ballotpedia 95,894 vs. OFR 97,110).
    Brookings is used throughout for consistency with the original series.

## D6 — US GDP, nominal dollars per year (`D6_gdp_dollars.csv`)

- **Source:** World Bank World Development Indicators, indicator NY.GDP.MKTP.CD
  ("GDP, current US$") for the United States. WDI US GDP is sourced from
  BEA national accounts (via OECD).
- **URL (API):** https://api.worldbank.org/v2/country/US/indicator/NY.GDP.MKTP.CD?format=json&date=1960:2024&per_page=100
- **Coverage:** Annual 1960–2024, in **dollars** (not billions), matching the
  original `.dat` scale (1960 = 5.433E+11).
- **Methodology notes:**
  - The full 1960–2024 series is a **single consistent vintage** (WDI, reflecting
    BEA data through the 2025 annual revision). This replaces the original
    `.dat` values, which were 2015-vintage BEA. The BEA's comprehensive
    revisions raised historical levels slightly (e.g., 2014: $17.419T in the
    original `.dat` → $17.608T here, ~1.1%). If the model team prefers to
    preserve the original 1960–2014 values exactly and splice, the seam is at
    2014/2015.
  - Cross-checked 2021–2024 against FRED series GDPA (BEA, "Gross Domestic
    Product", annual, billions of dollars, NSA):
    https://fred.stlouisfed.org/series/GDPA — WDI matches FRED's pre-Sep-2026
    vintage exactly (2024: $29,298.013B). Note: BEA's Sep-2026 annual revision
    (published after WDI's update) raised these slightly — FRED Sep-2026 vintage:
    2021: 23,745.848, 2022: 26,059.709, 2023: 27,825.886, 2024: 29,380.991
    (billions). Not incorporated; differences are 0.1–0.3%.
  - 2024 GDP = $29,298,013,000,000.

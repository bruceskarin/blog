"""Run policy scenarios for the 2026 model update.

Scenarios (all start 2027):
- baseline: no policy changes
- voucher: $35/voter/year, 25% participation
- match: 9:1 small-dollar match
- cost: media cost control (0.1%/yr growth)
- leverage: 20% reduction in transparency leverage (TBD - need to find param)
- voucher+cost: combined
- voucher+cost+leverage: combined

Outputs: CSV files per scenario with key indicators.
"""
import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import pysd
from pysd.py_backend import lookups
import time

# Fast lookup patch
_orig_call = lookups.HardcodedLookups._call
def _fast_call(self, data, x, final_subs=None):
    if self.is_float and not hasattr(x, 'dims'):
        xp = data['lookup_dim'].values
        fp = np.asarray(data.values, dtype=float)
        return float(np.interp(float(x), xp, fp))
    return _orig_call(self, data, x, final_subs)
lookups.HardcodedLookups._call = _fast_call

MODEL = '/home/hatch/workspace/icorrupt-refresh/model/model_2026_updated.mdl'
OUTDIR = '/home/hatch/workspace/icorrupt-refresh/model/scenarios'

INDICATORS = [
    'Trust In Government',
    'Middle Class Contributions Under $200',
    'Elite Contributions Over $2700',
    'Elite to Middle Class Contribution Ratio',
    'Total Spending on Lobbyists',
    'Ratio Top 5 Percent to Middle Class',
]

SCENARIOS = {
    'baseline': {},
    'voucher': {
        'voucher policy amount per voter': 35,
    },
    'match': {
        'public funding match dollar multiplier': 9,
    },
    'cost': {
        'cost control rate': 0.001,
    },
    'voucher_cost': {
        'voucher policy amount per voter': 35,
        'cost control rate': 0.001,
    },
}

def run_scenario(name, params):
    print(f"\n=== {name} ===", flush=True)
    t0 = time.time()
    model = pysd.read_vensim(MODEL)
    print(f"  loaded in {time.time()-t0:.1f}s", flush=True)
    t0 = time.time()
    if params:
        result = model.run(params=params, return_columns=INDICATORS)
    else:
        result = model.run(return_columns=INDICATORS)
    print(f"  ran in {time.time()-t0:.1f}s", flush=True)
    outpath = f"{OUTDIR}/{name}.csv"
    result.to_csv(outpath)
    print(f"  saved to {outpath}", flush=True)
    return result

def main():
    import os
    os.makedirs(OUTDIR, exist_ok=True)
    results = {}
    for name, params in SCENARIOS.items():
        results[name] = run_scenario(name, params)
    
    # Summary comparison at 2050
    print("\n=== 2050 Comparison ===")
    print(f"{'Scenario':<15} {'Trust':<8} {'MC <$200':<12} {'Elite':<12}")
    for name in SCENARIOS:
        df = results[name]
        # time is the index
        row = df.loc[2050]
        print(f"{name:<15} {row['Trust In Government']:<8.1f} "
              f"${row['Middle Class Contributions Under $200']/1e6:<11.1f}M "
              f"${row['Elite Contributions Over $2700']/1e6:<11.1f}M")

if __name__ == '__main__':
    main()
